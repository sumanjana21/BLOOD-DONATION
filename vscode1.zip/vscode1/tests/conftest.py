import pytest
from admin import app, db

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for tests
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client