from admin import Admin, db

def test_create_admin():
    admin = Admin(username='testuser', email='test@example.com')
    admin.set_password('secret')
    db.session.add(admin)
    db.session.commit()
    assert admin.check_password('secret')
    assert admin.username == 'testuser'
    assert admin.email == 'test@example.com'