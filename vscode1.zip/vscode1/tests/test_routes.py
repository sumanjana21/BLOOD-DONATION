def test_login_page(client):
    rv = client.get('/login')
    assert rv.status_code == 200
    assert b'Serenity Admin' in rv.data

def test_login_post(client):
    # Create admin first
    from admin import Admin, db
    admin = Admin(username='admin', email='admin@example.com')
    admin.set_password('admin123')
    db.session.add(admin)
    db.session.commit()

    rv = client.post('/login', data={
        'username': 'admin',
        'password': 'admin123'
    }, follow_redirects=True)
    assert rv.status_code == 200
    assert b'Login successful' in rv.data

def test_dashboard_access_without_login(client):
    rv = client.get('/dashboard', follow_redirects=True)
    assert b'Please log in' in rv.data