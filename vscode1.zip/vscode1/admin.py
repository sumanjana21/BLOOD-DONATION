"""
Serenity Hospital Blood Donation System – Enhanced Version
Includes Flask‑Login, Flask‑WTF, python‑dotenv, logging, and test suite.
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, SelectField, TextAreaField, BooleanField
from wtforms.validators import DataRequired, Email, Length, NumberRange, Optional
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///serenity_hospital.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'info'

# ==================== LOGGING CONFIGURATION ====================
if not os.path.exists('logs'):
    os.mkdir('logs')
file_handler = RotatingFileHandler('logs/serenity.log', maxBytes=10240, backupCount=10)
file_handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
))
file_handler.setLevel(logging.INFO)
app.logger.addHandler(file_handler)
app.logger.setLevel(logging.INFO)
app.logger.info('Serenity Hospital startup')

# ==================== DATABASE MODELS ====================

class Admin(UserMixin, db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Hospital(db.Model):
    __tablename__ = 'hospitals'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    distance = db.Column(db.String(20))
    phone = db.Column(db.String(20), nullable=False)
    emergency_phone = db.Column(db.String(20))
    fax = db.Column(db.String(20))
    services = db.Column(db.Text)
    trauma_level = db.Column(db.String(50))
    beds = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    blood_stocks = db.relationship('BloodStock', backref='hospital', lazy=True, cascade='all, delete-orphan')

class BloodStock(db.Model):
    __tablename__ = 'blood_stocks'
    id = db.Column(db.Integer, primary_key=True)
    hospital_id = db.Column(db.Integer, db.ForeignKey('hospitals.id'), nullable=False)
    blood_group = db.Column(db.String(5), nullable=False)
    units = db.Column(db.Integer, default=0)
    platelets = db.Column(db.Integer, default=0)
    plasma = db.Column(db.Integer, default=0)
    cryo = db.Column(db.Integer, default=0)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Camp(db.Model):
    __tablename__ = 'camps'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    organizer = db.Column(db.String(100), nullable=False)
    badge = db.Column(db.String(50))
    location = db.Column(db.String(200), nullable=False)
    address = db.Column(db.String(200))
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    time = db.Column(db.String(50))
    is_24h = db.Column(db.Boolean, default=False)
    medical_director = db.Column(db.String(100))
    benefits = db.Column(db.Text)
    contact_phone = db.Column(db.String(20))
    total_spots = db.Column(db.Integer, default=100)
    registered_spots = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='upcoming')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    registrations = db.relationship('CampRegistration', backref='camp', lazy=True, cascade='all, delete-orphan')

class CampRegistration(db.Model):
    __tablename__ = 'camp_registrations'
    id = db.Column(db.Integer, primary_key=True)
    camp_id = db.Column(db.Integer, db.ForeignKey('camps.id'), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    age = db.Column(db.Integer)
    blood_group = db.Column(db.String(5))
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='confirmed')

class Donor(db.Model):
    __tablename__ = 'donors'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    age = db.Column(db.Integer)
    blood_group = db.Column(db.String(5))
    address = db.Column(db.String(200))
    medical_conditions = db.Column(db.Text)
    last_donation_date = db.Column(db.Date)
    total_donations = db.Column(db.Integer, default=0)
    status = db.Column(db.String(20), default='active')
    registered_date = db.Column(db.DateTime, default=datetime.utcnow)

    donations = db.relationship('DonationHistory', backref='donor', lazy=True, cascade='all, delete-orphan')

class DonationHistory(db.Model):
    __tablename__ = 'donation_history'
    id = db.Column(db.Integer, primary_key=True)
    donor_id = db.Column(db.Integer, db.ForeignKey('donors.id'), nullable=False)
    hospital_id = db.Column(db.Integer, db.ForeignKey('hospitals.id'))
    camp_id = db.Column(db.Integer, db.ForeignKey('camps.id'))
    donation_date = db.Column(db.DateTime, default=datetime.utcnow)
    blood_group = db.Column(db.String(5))
    units_donated = db.Column(db.Integer, default=1)
    hemoglobin = db.Column(db.Float)
    notes = db.Column(db.Text)

class BloodRequest(db.Model):
    __tablename__ = 'blood_requests'
    id = db.Column(db.Integer, primary_key=True)
    patient_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    doctor_name = db.Column(db.String(100))
    hospital_id = db.Column(db.Integer, db.ForeignKey('hospitals.id'))
    blood_group = db.Column(db.String(5), nullable=False)
    units_needed = db.Column(db.Integer, default=1)
    urgency = db.Column(db.String(20), default='normal')
    diagnosis = db.Column(db.String(200))
    additional_info = db.Column(db.Text)
    request_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')
    fulfilled_date = db.Column(db.DateTime)

class ContactMessage(db.Model):
    __tablename__ = 'contact_messages'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    replied = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SystemLog(db.Model):
    __tablename__ = 'system_logs'
    id = db.Column(db.Integer, primary_key=True)
    action = db.Column(db.String(100), nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey('admins.id'))
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# ==================== FLASK-LOGIN USER LOADER ====================
@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

# ==================== FORMS (Flask-WTF) ====================

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=50)])
    password = PasswordField('Password', validators=[DataRequired()])

class HospitalForm(FlaskForm):
    name = StringField('Hospital Name', validators=[DataRequired(), Length(max=100)])
    address = StringField('Address', validators=[DataRequired(), Length(max=200)])
    city = StringField('City', validators=[DataRequired(), Length(max=50)])
    distance = StringField('Distance', validators=[Optional(), Length(max=20)])
    phone = StringField('Phone', validators=[DataRequired(), Length(max=20)])
    emergency_phone = StringField('Emergency Phone', validators=[Optional(), Length(max=20)])
    fax = StringField('Fax', validators=[Optional(), Length(max=20)])
    services = TextAreaField('Services (comma separated)', validators=[Optional()])
    trauma_level = StringField('Trauma Level', validators=[Optional(), Length(max=50)])
    beds = IntegerField('Total Beds', validators=[Optional()])

class BloodStockForm(FlaskForm):
    units = IntegerField('Red Blood Cells (Units)', validators=[DataRequired(), NumberRange(min=0)])
    platelets = IntegerField('Platelets (Units)', validators=[DataRequired(), NumberRange(min=0)])
    plasma = IntegerField('Plasma (Units)', validators=[DataRequired(), NumberRange(min=0)])
    cryo = IntegerField('Cryoprecipitate (Units)', validators=[DataRequired(), NumberRange(min=0)])

class CampForm(FlaskForm):
    title = StringField('Camp Title', validators=[DataRequired(), Length(max=100)])
    organizer = StringField('Organizer', validators=[DataRequired(), Length(max=100)])
    badge = SelectField('Badge/Category', choices=[
        ('Hospital Camp', '🏥 Hospital Camp'),
        ('Community', '🏘️ Community'),
        ('Emergency', '🚨 Emergency')
    ], validators=[Optional()])
    location = StringField('Location', validators=[DataRequired(), Length(max=200)])
    address = StringField('Full Address', validators=[Optional(), Length(max=200)])
    start_date = StringField('Start Date (YYYY-MM-DD)', validators=[DataRequired()])
    end_date = StringField('End Date (YYYY-MM-DD)', validators=[DataRequired()])
    time = StringField('Time', validators=[Optional(), Length(max=50)])
    is_24h = BooleanField('24 Hours / Open all night')
    medical_director = StringField('Medical Director', validators=[Optional(), Length(max=100)])
    benefits = TextAreaField('Benefits', validators=[Optional()])
    contact_phone = StringField('Contact Phone', validators=[Optional(), Length(max=20)])
    total_spots = IntegerField('Total Spots', default=100, validators=[DataRequired()])
    status = SelectField('Status', choices=[
        ('upcoming', 'Upcoming'),
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed')
    ], validators=[DataRequired()])

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField('Current Password', validators=[DataRequired()])
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm New Password', validators=[DataRequired()])

# ==================== ROUTES ====================

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    form = LoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data).first()
        if admin and admin.check_password(form.password.data):
            login_user(admin, remember=True)
            flash('Login successful!', 'success')
            app.logger.info(f'Admin {admin.username} logged in from {request.remote_addr}')
            log = SystemLog(action='Admin Login', admin_id=admin.id,
                           details=f'Admin {admin.username} logged in',
                           ip_address=request.remote_addr)
            db.session.add(log)
            db.session.commit()
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'danger')
            app.logger.warning(f'Failed login attempt for username: {form.username.data}')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    app.logger.info(f'Admin {current_user.username} logged out')
    log = SystemLog(action='Admin Logout', admin_id=current_user.id,
                   details=f'Admin {current_user.username} logged out')
    db.session.add(log)
    db.session.commit()
    logout_user()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('login'))

@app.route('/website')
def view_website():
    return render_template('index.html')

# ==================== API ENDPOINTS (unchanged) ====================

@app.route('/api/hospitals', methods=['GET'])
def api_get_hospitals():
    try:
        hospitals = Hospital.query.all()
        hospital_list = []
        for hospital in hospitals:
            services_list = [s.strip() for s in hospital.services.split(',')] if hospital.services else []
            hospital_list.append({
                'id': hospital.id,
                'name': hospital.name,
                'address': hospital.address,
                'city': hospital.city,
                'distance': hospital.distance or 'N/A',
                'phone': hospital.phone,
                'emergency_phone': hospital.emergency_phone or hospital.phone,
                'services': services_list,
                'trauma_level': hospital.trauma_level or 'General Hospital',
                'beds': hospital.beds or 0
            })
        return jsonify(hospital_list)
    except Exception as e:
        app.logger.error(f'Error in api_get_hospitals: {str(e)}')
        return jsonify([]), 500

@app.route('/api/blood-stock', methods=['GET'])
def api_get_blood_stock():
    try:
        stocks = BloodStock.query.all()
        result = []
        for stock in stocks:
            hospital = Hospital.query.get(stock.hospital_id)
            result.append({
                'hospital_id': stock.hospital_id,
                'hospital_name': hospital.name if hospital else 'Unknown',
                'blood_group': stock.blood_group,
                'units': stock.units,
                'platelets': stock.platelets,
                'plasma': stock.plasma,
                'cryo': stock.cryo,
                'last_updated': stock.last_updated.strftime('%Y-%m-%d %H:%M') if stock.last_updated else ''
            })
        return jsonify(result)
    except Exception as e:
        app.logger.error(f'Error in api_get_blood_stock: {str(e)}')
        return jsonify([]), 500

@app.route('/api/camps', methods=['GET'])
def api_get_camps():
    try:
        camps = Camp.query.all()
        camp_list = []
        for camp in camps:
            progress = (camp.registered_spots / camp.total_spots * 100) if camp.total_spots > 0 else 0
            badge_map = {
                'Hospital Camp': '🏥 Hospital Camp',
                'Community': '🏘️ Community',
                'Emergency': '🚨 Emergency'
            }
            start_date = camp.start_date.strftime('%B %d, %Y') if camp.start_date else 'TBD'
            end_date = camp.end_date.strftime('%B %d, %Y') if camp.end_date else 'TBD'
            camp_list.append({
                'id': camp.id,
                'title': camp.title,
                'organizer': camp.organizer,
                'badge': badge_map.get(camp.badge, camp.badge or 'Blood Camp'),
                'location': camp.location,
                'address': camp.address or camp.location,
                'start_date': start_date,
                'end_date': end_date,
                'time': camp.time or '9:00 AM - 5:00 PM',
                'is_24h': camp.is_24h,
                'medical_director': camp.medical_director or 'Medical Team',
                'benefits': camp.benefits or 'Free health checkup, juice, snacks',
                'contact_phone': camp.contact_phone or 'N/A',
                'registered_spots': camp.registered_spots,
                'total_spots': camp.total_spots,
                'progress': round(progress, 1),
                'status': camp.status
            })
        return jsonify(camp_list)
    except Exception as e:
        app.logger.error(f'Error in api_get_camps: {str(e)}')
        return jsonify([]), 500

@app.route('/api/donor/register', methods=['POST'])
def api_donor_register():
    data = request.json
    try:
        donor = Donor(
            full_name=data.get('name'),
            email=data.get('email'),
            phone=data.get('phone'),
            age=int(data.get('age', 0)),
            blood_group=data.get('blood_group'),
            address=data.get('address', ''),
            status='active'
        )
        db.session.add(donor)
        db.session.commit()
        app.logger.info(f'New donor registered: {data.get("name")}')
        log = SystemLog(action='Donor Registration',
                       details=f'New donor registered: {data.get("name")}',
                       ip_address=request.remote_addr)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Donor registered successfully!'})
    except Exception as e:
        app.logger.error(f'Error in donor registration: {str(e)}')
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/blood/request', methods=['POST'])
def api_blood_request():
    data = request.json
    try:
        hospital = Hospital.query.filter_by(name=data.get('hospital')).first()
        blood_request = BloodRequest(
            patient_name=data.get('patient_name'),
            email=data.get('email'),
            phone=data.get('phone'),
            hospital_id=hospital.id if hospital else None,
            blood_group=data.get('blood_group'),
            units_needed=int(data.get('units', 1)),
            urgency='normal',
            status='pending'
        )
        db.session.add(blood_request)
        db.session.commit()
        app.logger.info(f'Blood request for {data.get("patient_name")}')
        log = SystemLog(action='Blood Request',
                       details=f'Blood request for {data.get("patient_name")}',
                       ip_address=request.remote_addr)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Blood request submitted successfully!'})
    except Exception as e:
        app.logger.error(f'Error in blood request: {str(e)}')
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/camp/register', methods=['POST'])
def api_camp_register():
    data = request.json
    try:
        camp = Camp.query.filter_by(title=data.get('camp_name')).first()
        if not camp:
            return jsonify({'success': False, 'message': 'Camp not found'}), 404
        if camp.registered_spots >= camp.total_spots:
            return jsonify({'success': False, 'message': 'Camp is fully booked'}), 400
        registration = CampRegistration(
            camp_id=camp.id,
            full_name=data.get('name'),
            email=data.get('email'),
            phone=data.get('phone'),
            age=int(data.get('age', 0)),
            blood_group=data.get('blood_group'),
            status='confirmed'
        )
        db.session.add(registration)
        camp.registered_spots += 1
        db.session.commit()
        app.logger.info(f'Camp registration for {camp.title}')
        log = SystemLog(action='Camp Registration',
                       details=f'Registration for camp: {camp.title}',
                       ip_address=request.remote_addr)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Camp registration successful!'})
    except Exception as e:
        app.logger.error(f'Error in camp registration: {str(e)}')
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/contact', methods=['POST'])
def api_contact():
    data = request.json
    try:
        message = ContactMessage(
            name=data.get('name'),
            email=data.get('email'),
            phone=data.get('phone', ''),
            message=data.get('message'),
            is_read=False,
            replied=False
        )
        db.session.add(message)
        db.session.commit()
        app.logger.info(f'Contact message from {data.get("name")}')
        log = SystemLog(action='Contact Message',
                       details=f'Message from {data.get("name")}',
                       ip_address=request.remote_addr)
        db.session.add(log)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Message sent successfully!'})
    except Exception as e:
        app.logger.error(f'Error in contact message: {str(e)}')
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/stats', methods=['GET'])
def api_get_stats():
    try:
        stats = {
            'hospitals': Hospital.query.count(),
            'camps': Camp.query.filter_by(status='upcoming').count(),
            'total_blood_units': db.session.query(db.func.sum(BloodStock.units)).scalar() or 0,
            'total_donors': Donor.query.count()
        }
        return jsonify(stats)
    except Exception as e:
        app.logger.error(f'Error in stats: {str(e)}')
        return jsonify({'hospitals': 0, 'camps': 0, 'total_blood_units': 0, 'total_donors': 0}), 500

# ==================== EXPORT DATA TO EXCEL ====================

def export_to_excel():
    wb = openpyxl.Workbook()
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="c0392b", end_color="c0392b", fill_type="solid")

    def write_table(sheet, model, columns):
        sheet.append(columns)
        for cell in sheet[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")
        for obj in model.query.all():
            row = []
            for col in columns:
                if hasattr(obj, col):
                    val = getattr(obj, col)
                    if isinstance(val, datetime):
                        val = val.strftime('%Y-%m-%d %H:%M:%S')
                    elif isinstance(val, (datetime.date, type(datetime.utcnow().date()))):
                        val = val.strftime('%Y-%m-%d')
                    row.append(val)
                else:
                    row.append('')
            sheet.append(row)
        for col in sheet.columns:
            max_length = 0
            column = col[0].column_letter
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = (max_length + 2)
            sheet.column_dimensions[column].width = min(adjusted_width, 50)

    # Sheets
    ws = wb.active
    ws.title = "Admins"
    write_table(ws, Admin, ['id', 'username', 'email', 'created_at'])

    ws = wb.create_sheet("Hospitals")
    write_table(ws, Hospital, ['id', 'name', 'address', 'city', 'distance', 'phone', 'emergency_phone', 'fax', 'services', 'trauma_level', 'beds', 'created_at'])

    ws = wb.create_sheet("BloodStock")
    write_table(ws, BloodStock, ['id', 'hospital_id', 'blood_group', 'units', 'platelets', 'plasma', 'cryo', 'last_updated'])

    ws = wb.create_sheet("Camps")
    write_table(ws, Camp, ['id', 'title', 'organizer', 'badge', 'location', 'address', 'start_date', 'end_date', 'time', 'is_24h', 'medical_director', 'benefits', 'contact_phone', 'total_spots', 'registered_spots', 'status', 'created_at'])

    ws = wb.create_sheet("CampRegistrations")
    write_table(ws, CampRegistration, ['id', 'camp_id', 'full_name', 'email', 'phone', 'age', 'blood_group', 'registration_date', 'status'])

    ws = wb.create_sheet("Donors")
    write_table(ws, Donor, ['id', 'full_name', 'email', 'phone', 'age', 'blood_group', 'address', 'medical_conditions', 'last_donation_date', 'total_donations', 'status', 'registered_date'])

    ws = wb.create_sheet("DonationHistory")
    write_table(ws, DonationHistory, ['id', 'donor_id', 'hospital_id', 'camp_id', 'donation_date', 'blood_group', 'units_donated', 'hemoglobin', 'notes'])

    ws = wb.create_sheet("BloodRequests")
    write_table(ws, BloodRequest, ['id', 'patient_name', 'email', 'phone', 'doctor_name', 'hospital_id', 'blood_group', 'units_needed', 'urgency', 'diagnosis', 'additional_info', 'request_date', 'status', 'fulfilled_date'])

    ws = wb.create_sheet("ContactMessages")
    write_table(ws, ContactMessage, ['id', 'name', 'email', 'phone', 'message', 'is_read', 'replied', 'created_at'])

    ws = wb.create_sheet("SystemLogs")
    write_table(ws, SystemLog, ['id', 'action', 'admin_id', 'details', 'ip_address', 'timestamp'])

    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output

@app.route('/export-data')
@login_required
def export_data():
    try:
        output = export_to_excel()
        log = SystemLog(action='Export Data', admin_id=current_user.id,
                       details='Exported all data to Excel')
        db.session.add(log)
        db.session.commit()
        return send_file(output, download_name=f"serenity_hospital_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx", as_attachment=True)
    except Exception as e:
        app.logger.error(f'Export error: {str(e)}')
        flash(f'Error exporting data: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/export/data.xlsx')
@login_required
def export_data_fixed_filename():
    try:
        output = export_to_excel()
        log = SystemLog(action='Export Data (Fixed)', admin_id=current_user.id,
                       details='Exported all data to data.xlsx')
        db.session.add(log)
        db.session.commit()
        return send_file(output, download_name="data.xlsx", as_attachment=True)
    except Exception as e:
        app.logger.error(f'Export error: {str(e)}')
        flash(f'Error exporting data: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

# ==================== ADMIN DASHBOARD ====================

@app.route('/dashboard')
@login_required
def dashboard():
    stats = {
        'hospitals': Hospital.query.count(),
        'camps': Camp.query.filter_by(status='upcoming').count(),
        'donors': Donor.query.count(),
        'requests': BloodRequest.query.filter_by(status='pending').count(),
        'total_blood_units': db.session.query(db.func.sum(BloodStock.units)).scalar() or 0,
        'camp_registrations': CampRegistration.query.count(),
        'messages': ContactMessage.query.filter_by(is_read=False).count()
    }
    recent_donors = Donor.query.order_by(Donor.registered_date.desc()).limit(5).all()
    recent_requests = BloodRequest.query.order_by(BloodRequest.request_date.desc()).limit(5).all()
    recent_camps = Camp.query.order_by(Camp.start_date.desc()).limit(5).all()
    return render_template('dashboard.html', stats=stats, recent_donors=recent_donors,
                           recent_requests=recent_requests, recent_camps=recent_camps)

# ==================== HOSPITALS ====================

@app.route('/hospitals')
@login_required
def hospitals_list():
    hospitals = Hospital.query.all()
    return render_template('hospitals_list.html', hospitals=hospitals)

@app.route('/hospitals/add', methods=['GET', 'POST'])
@login_required
def add_hospital():
    form = HospitalForm()
    if form.validate_on_submit():
        hospital = Hospital(
            name=form.name.data,
            address=form.address.data,
            city=form.city.data,
            distance=form.distance.data or '',
            phone=form.phone.data,
            emergency_phone=form.emergency_phone.data or '',
            fax=form.fax.data or '',
            services=form.services.data or '',
            trauma_level=form.trauma_level.data or '',
            beds=form.beds.data
        )
        db.session.add(hospital)
        db.session.commit()
        blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
        for bg in blood_groups:
            stock = BloodStock(hospital_id=hospital.id, blood_group=bg, units=10, platelets=5, plasma=8, cryo=3)
            db.session.add(stock)
        db.session.commit()
        app.logger.info(f'New hospital added: {hospital.name} by {current_user.username}')
        flash(f'Hospital "{hospital.name}" added successfully!', 'success')
        return redirect(url_for('hospitals_list'))
    return render_template('hospital_form.html', form=form, title='Add Hospital')

@app.route('/hospitals/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_hospital(id):
    hospital = Hospital.query.get_or_404(id)
    form = HospitalForm(obj=hospital)
    if form.validate_on_submit():
        form.populate_obj(hospital)
        db.session.commit()
        app.logger.info(f'Hospital edited: {hospital.name} by {current_user.username}')
        flash('Hospital updated successfully!', 'success')
        return redirect(url_for('hospitals_list'))
    return render_template('hospital_form.html', form=form, title='Edit Hospital', hospital=hospital)

@app.route('/hospitals/delete/<int:id>', methods=['POST'])
@login_required
def delete_hospital(id):
    hospital = Hospital.query.get_or_404(id)
    name = hospital.name
    db.session.delete(hospital)
    db.session.commit()
    app.logger.info(f'Hospital deleted: {name} by {current_user.username}')
    flash(f'Hospital "{name}" deleted.', 'success')
    return redirect(url_for('hospitals_list'))

# ==================== BLOOD STOCK ====================

@app.route('/blood-stock')
@login_required
def blood_stock_list():
    hospitals = Hospital.query.all()
    return render_template('blood_stock_list.html', hospitals=hospitals)

@app.route('/blood-stock/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_blood_stock(id):
    stock = BloodStock.query.get_or_404(id)
    form = BloodStockForm(obj=stock)
    if form.validate_on_submit():
        form.populate_obj(stock)
        db.session.commit()
        app.logger.info(f'Blood stock updated: {stock.blood_group} at {stock.hospital.name} by {current_user.username}')
        flash('Blood stock updated successfully!', 'success')
        return redirect(url_for('blood_stock_list'))
    return render_template('blood_stock_form.html', form=form, stock=stock)

# ==================== CAMPS ====================

@app.route('/camps')
@login_required
def camps_list():
    camps = Camp.query.order_by(Camp.start_date.desc()).all()
    return render_template('camps_list.html', camps=camps)

@app.route('/camps/add', methods=['GET', 'POST'])
@login_required
def add_camp():
    form = CampForm()
    if form.validate_on_submit():
        camp = Camp(
            title=form.title.data,
            organizer=form.organizer.data,
            badge=form.badge.data,
            location=form.location.data,
            address=form.address.data or '',
            start_date=datetime.strptime(form.start_date.data, '%Y-%m-%d').date(),
            end_date=datetime.strptime(form.end_date.data, '%Y-%m-%d').date(),
            time=form.time.data or '',
            is_24h=form.is_24h.data,
            medical_director=form.medical_director.data or '',
            benefits=form.benefits.data or '',
            contact_phone=form.contact_phone.data or '',
            total_spots=form.total_spots.data,
            status=form.status.data
        )
        db.session.add(camp)
        db.session.commit()
        app.logger.info(f'New camp added: {camp.title} by {current_user.username}')
        flash(f'Camp "{camp.title}" added successfully!', 'success')
        return redirect(url_for('camps_list'))
    return render_template('camp_form.html', form=form, title='Add Camp')

@app.route('/camps/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_camp(id):
    camp = Camp.query.get_or_404(id)
    # Convert dates to string for form
    camp.start_date_str = camp.start_date.strftime('%Y-%m-%d') if camp.start_date else ''
    camp.end_date_str = camp.end_date.strftime('%Y-%m-%d') if camp.end_date else ''
    form = CampForm(obj=camp)
    if form.validate_on_submit():
        camp.title = form.title.data
        camp.organizer = form.organizer.data
        camp.badge = form.badge.data
        camp.location = form.location.data
        camp.address = form.address.data or ''
        camp.start_date = datetime.strptime(form.start_date.data, '%Y-%m-%d').date()
        camp.end_date = datetime.strptime(form.end_date.data, '%Y-%m-%d').date()
        camp.time = form.time.data or ''
        camp.is_24h = form.is_24h.data
        camp.medical_director = form.medical_director.data or ''
        camp.benefits = form.benefits.data or ''
        camp.contact_phone = form.contact_phone.data or ''
        camp.total_spots = form.total_spots.data
        camp.status = form.status.data
        db.session.commit()
        app.logger.info(f'Camp edited: {camp.title} by {current_user.username}')
        flash('Camp updated successfully!', 'success')
        return redirect(url_for('camps_list'))
    # Pre-populate date fields
    form.start_date.data = camp.start_date.strftime('%Y-%m-%d') if camp.start_date else ''
    form.end_date.data = camp.end_date.strftime('%Y-%m-%d') if camp.end_date else ''
    return render_template('camp_form.html', form=form, title='Edit Camp', camp=camp)

@app.route('/camps/delete/<int:id>', methods=['POST'])
@login_required
def delete_camp(id):
    camp = Camp.query.get_or_404(id)
    title = camp.title
    db.session.delete(camp)
    db.session.commit()
    app.logger.info(f'Camp deleted: {title} by {current_user.username}')
    flash(f'Camp "{title}" deleted.', 'success')
    return redirect(url_for('camps_list'))

@app.route('/camps/<int:id>/registrations')
@login_required
def camp_registrations(id):
    camp = Camp.query.get_or_404(id)
    registrations = CampRegistration.query.filter_by(camp_id=id).order_by(CampRegistration.registration_date.desc()).all()
    return render_template('camp_registrations.html', camp=camp, registrations=registrations)

# ==================== DONORS ====================

@app.route('/donors')
@login_required
def donors_list():
    donors = Donor.query.order_by(Donor.registered_date.desc()).all()
    return render_template('donors_list.html', donors=donors)

@app.route('/donors/<int:id>')
@login_required
def donor_details(id):
    donor = Donor.query.get_or_404(id)
    donations = DonationHistory.query.filter_by(donor_id=id).order_by(DonationHistory.donation_date.desc()).all()
    return render_template('donor_details.html', donor=donor, donations=donations)

# ==================== BLOOD REQUESTS ====================

@app.route('/requests')
@login_required
def requests_list():
    filter_status = request.args.get('filter', 'all')
    if filter_status == 'pending':
        requests = BloodRequest.query.filter_by(status='pending').order_by(BloodRequest.request_date.desc()).all()
    elif filter_status == 'approved':
        requests = BloodRequest.query.filter_by(status='approved').order_by(BloodRequest.request_date.desc()).all()
    elif filter_status == 'fulfilled':
        requests = BloodRequest.query.filter_by(status='fulfilled').order_by(BloodRequest.request_date.desc()).all()
    else:
        requests = BloodRequest.query.order_by(BloodRequest.request_date.desc()).all()
    return render_template('requests_list.html', requests=requests, filter_status=filter_status)

@app.route('/requests/<int:id>/status/<status>')
@login_required
def update_request_status(id, status):
    req = BloodRequest.query.get_or_404(id)
    req.status = status
    if status == 'fulfilled':
        req.fulfilled_date = datetime.utcnow()
        stock = BloodStock.query.filter_by(hospital_id=req.hospital_id, blood_group=req.blood_group).first()
        if stock and stock.units >= req.units_needed:
            stock.units -= req.units_needed
    db.session.commit()
    app.logger.info(f'Request {id} status updated to {status} by {current_user.username}')
    flash(f'Request status updated to {status}', 'success')
    return redirect(url_for('requests_list'))

# ==================== MESSAGES ====================

@app.route('/messages')
@login_required
def messages_list():
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()
    return render_template('messages_list.html', messages=messages)

@app.route('/messages/<int:id>/read')
@login_required
def mark_message_read(id):
    msg = ContactMessage.query.get_or_404(id)
    msg.is_read = True
    db.session.commit()
    flash('Message marked as read', 'success')
    return redirect(url_for('messages_list'))

# ==================== SYSTEM LOGS ====================

@app.route('/logs')
@login_required
def system_logs():
    logs = SystemLog.query.order_by(SystemLog.timestamp.desc()).limit(100).all()
    return render_template('system_logs.html', logs=logs)

# ==================== REPORTS ====================

@app.route('/reports')
@login_required
def reports():
    total_donors = Donor.query.count()
    total_requests = BloodRequest.query.count()
    fulfilled_requests = BloodRequest.query.filter_by(status='fulfilled').count()
    total_donations = db.session.query(db.func.sum(DonationHistory.units_donated)).scalar() or 0

    blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
    blood_distribution = {}
    donor_blood_groups = {}
    for bg in blood_groups:
        blood_distribution[bg] = db.session.query(db.func.sum(BloodStock.units)).filter_by(blood_group=bg).scalar() or 0
        donor_blood_groups[bg] = Donor.query.filter_by(blood_group=bg).count()

    return render_template('reports.html',
                           total_donors=total_donors,
                           total_requests=total_requests,
                           fulfilled_requests=fulfilled_requests,
                           total_donations=total_donations,
                           blood_distribution=blood_distribution,
                           donor_blood_groups=donor_blood_groups)

# ==================== SETTINGS ====================

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.current_password.data):
            flash('Current password is incorrect.', 'danger')
        elif form.new_password.data != form.confirm_password.data:
            flash('New passwords do not match.', 'danger')
        else:
            current_user.set_password(form.new_password.data)
            db.session.commit()
            app.logger.info(f'Password changed for {current_user.username}')
            flash('Password changed successfully!', 'success')
        return redirect(url_for('settings'))
    return render_template('settings.html', form=form)

# ==================== ERROR HANDLERS ====================

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

# ==================== DATABASE INITIALIZATION ====================

def init_db():
    with app.app_context():
        db.create_all()
        if not Admin.query.filter_by(username='admin').first():
            admin = Admin(username='admin', email='admin@serenity.com')
            admin.set_password(os.getenv('DEFAULT_ADMIN_PASSWORD', 'admin123'))
            db.session.add(admin)
            db.session.commit()
            app.logger.info('Default admin created.')
        # Sample data (as in original)
        if Hospital.query.count() == 0:
            hospitals = [
                Hospital(name='City General Hospital', address='123 Main Street', city='Manhattan',
                         distance='2.3 km', phone='+1 (212) 555-0100', emergency_phone='+1 (212) 555-0111',
                         services='Cardiology, Neurology, Pediatrics, Trauma', trauma_level='Level 1 Trauma Center', beds=380),
                Hospital(name='Mount Sinai Medical', address='456 Park Avenue', city='Midtown',
                         distance='3.1 km', phone='+1 (212) 555-2300', emergency_phone='+1 (212) 555-2311',
                         services='Cardiology, Oncology, Orthopedics, Neurology', trauma_level='Level 2 Trauma Center', beds=220),
                Hospital(name='NYU Langone Health', address='789 Broadway', city='Downtown',
                         distance='4.5 km', phone='+1 (212) 555-7800', emergency_phone='+1 (212) 555-7811',
                         services='Transplant, Neurosurgery, Cardiology, Pediatrics', trauma_level='Level 1 Trauma Center', beds=450)
            ]
            for hospital in hospitals:
                db.session.add(hospital)
            db.session.commit()
            blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
            for hospital in hospitals:
                for bg in blood_groups:
                    stock = BloodStock(hospital_id=hospital.id, blood_group=bg, units=20, platelets=5, plasma=10, cryo=3)
                    db.session.add(stock)
            db.session.commit()
            app.logger.info('Sample hospitals and blood stock added.')

        if Camp.query.count() == 0:
            camps = [
                Camp(title='City General Hospital Camp', organizer='City Health Department', badge='Hospital Camp',
                     location='123 Main St, Manhattan', address='Main Lobby',
                     start_date=datetime(2024, 3, 15).date(), end_date=datetime(2024, 3, 20).date(),
                     time='9:00 AM – 6:00 PM', medical_director='Dr. Meera Krishnan',
                     benefits='Free health checkup, juice, snacks, T-shirt', contact_phone='(212) 555-0100',
                     total_spots=100, registered_spots=45, status='upcoming'),
                Camp(title='Brooklyn Community Center', organizer='American Red Cross', badge='Community',
                     location='456 Oak Ave, Brooklyn', address='Hall A',
                     start_date=datetime(2024, 3, 18).date(), end_date=datetime(2024, 3, 19).date(),
                     time='10:00 AM – 4:00 PM', medical_director='Nurse Sarah Johnson',
                     benefits='Free T-shirt, donor badge, refreshments', contact_phone='(718) 555-0123',
                     total_spots=75, registered_spots=28, status='upcoming'),
                Camp(title='Queens Emergency Drive', organizer='NY Blood Center', badge='Emergency',
                     location='321 Emergency Ln, Queens', address='Main Entrance',
                     start_date=datetime(2024, 3, 14).date(), end_date=datetime(2024, 3, 16).date(),
                     time='24 Hours', is_24h=True, medical_director='Trauma Team',
                     benefits='Free parking, hot meal, wellness kit', contact_phone='(718) 555-0456',
                     total_spots=150, registered_spots=89, status='upcoming')
            ]
            for camp in camps:
                db.session.add(camp)
            db.session.commit()
            app.logger.info('Sample camps added.')

if __name__ == '__main__':
    init_db()
    app.run(debug=os.getenv('FLASK_DEBUG', 'False').lower() == 'true', host='0.0.0.0', port=5000)